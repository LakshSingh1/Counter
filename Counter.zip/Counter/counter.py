from flask import Flask, redirect # Import Flask to allow us to create our app

app = Flask(__name__)    # Create a new instance of the Flask class called "app"

@app.route('/')
def root():
    global view_counter
    view_counter += 1
    return f'This page has been viewed {view_counter} times.'

@app.route('/destroy_session')
def destroy_session():
    session.clear()
    return redirect(url_for('root'))




if __name__=="__main__":   # Ensure this file is being run directly and not from a different module    
    app.run(debug=True, port=5001)    # Run the app in debug mode.
